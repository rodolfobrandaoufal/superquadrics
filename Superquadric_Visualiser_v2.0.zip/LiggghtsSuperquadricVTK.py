﻿#Programmable filter
#input = rigid*.vtk
#output = vtkUnstructuredGrid

#change according to your dataset
mname = "TENSOR"
n1name = "blockiness1"
n2name = "blockiness2"
scalexname = "shapex"
scaleyname = "shapey"
scalezname = "shapez"
switchname = "is_wall"
mainaxis = 1 # main paraview axis (0=x,1=y,2=z), in newer Paraview versions usually y for superquadric particles
phiresolution = 6 # number of points in phi direction
thetaresolution = 6 # number of points in theta direction
toroid = 0 # is superquadric particle toroid (0=no, 1=yes)
toroidthickness = 1 # thickness of toroid (0=large hole, 1=small hole)
toroidmode = 0 # toroid visualisation mode (0=keep height, 1=keep surface) 
basicscale = 1 # basic superquadric scaling
precision = 1 # output precision (0=single, 1=double)

#imported libraries
import vtk

#input/output
input = self.GetInputDataObject(0,0)
output = self.GetOutputDataObject(0)

#input properties
iPOINTS=input.GetPointData()
iBODIES=input.GetNumberOfPoints()
iARRAYS=iPOINTS.GetNumberOfArrays()

#set main axis rotation
if mainaxis==0: # if Paraview superquadric main axis is x
  rotx = 0
  roty = 90
  rotz = 0
if mainaxis==1: # if Paraview superquadric main axis is y
  rotx = 90
  roty = 0
  rotz = 0
if mainaxis==2: # if Paraview superquadric main axis is z
  rotx = 0
  roty = 0
  rotz = 0

#prepare output
newPoints = vtk.vtkPoints()
newCells = vtk.vtkCellArray()
newCellData = vtk.vtkCellData()

#prepare output arrays
oARRAYS = 0
skipMindex = -1
for i in range(0,iARRAYS):
 iarray=iPOINTS.GetAbstractArray(i)
 iname=iarray.GetName()
 icomp=iarray.GetNumberOfComponents()
 itype=iarray.GetDataType()
 #ignore rotation matrix - for faster skipping remember indexes
 if (iname!=mname):
   oarray=vtk.vtkAbstractArray.CreateArray(itype)
   oarray.SetName(iname)   
   oarray.SetNumberOfComponents(icomp)
   newCellData.AddArray(oarray)    
   oARRAYS += 1     
 elif (iname==mname):
   skipMindex = i

#check consistency
j = 0
for i in range(0,iARRAYS):
 iarray=iPOINTS.GetAbstractArray(i)
 iname=iarray.GetName()
 #ignore rotation matrix
 if (i!=skipMindex):
   oarray=newCellData.GetAbstractArray(j)
   oname=oarray.GetName()
   if (iname!=oname):
     print("Error: Non matching input/output array order!")
   j+=1

#create superquadric glyphs
oCELLPOINTS=0  
oCELLSURFACES=0 
for body in range(0,iBODIES):

 #skip data if switch is applied
 bswitcharr = iPOINTS.GetArray(switchname)
 if bswitcharr is not None:
   bswitch = bswitcharr.GetValue(body)
   if bswitch==1:
     continue
 
 #get parameters for superquadric particle

 #get particle position
 r=input.GetPoint(body)

 #get particle rotation matrix
 M=iPOINTS.GetAbstractArray(mname)

 #get particle blockiness and shape factors
 n1 = iPOINTS.GetArray(n1name).GetValue(body)
 n2 = iPOINTS.GetArray(n2name).GetValue(body)
 scalex = iPOINTS.GetArray(scalexname).GetValue(body)
 scaley = iPOINTS.GetArray(scaleyname).GetValue(body)
 scalez = iPOINTS.GetArray(scalezname).GetValue(body)

 #set toroid representation - make particle with correct height or surface
 if toroid==1:
   if toroidmode==0:
     if toroidthickness!=0:
       scalez = (1.0/toroidthickness+1.0)*scalez
     else:
       scalez = 1.0*scalez
   else:
     scalez = 1.0*scalez

 #compute rotation matrix
 T11=M.GetComponent(body,0)
 T12=M.GetComponent(body,1)
 T13=M.GetComponent(body,2)
 T21=M.GetComponent(body,3)
 T22=M.GetComponent(body,4)
 T23=M.GetComponent(body,5)
 T31=M.GetComponent(body,6)
 T32=M.GetComponent(body,7)
 T33=M.GetComponent(body,8)

 #make superquadric source
 superq = vtk.vtkSuperquadricSource()
 superq.SetCenter(0, 0, 0)
 superq.SetScale(scalex, scaley, scalez)
 superq.SetPhiRoundness(2.0/n1)
 superq.SetThetaRoundness(2.0/n2)
 superq.SetThickness(toroidthickness)
 superq.SetToroidal(toroid)
 superq.SetSize(basicscale)
 superq.SetPhiResolution(phiresolution)
 superq.SetThetaResolution(thetaresolution)
 superq.SetOutputPointsPrecision(precision)

 #rotate to basic z orientation
 transform = vtk.vtkTransform()
 transform.Translate(0,0,0)
 transform.RotateX(rotx)
 transform.RotateY(roty)
 transform.RotateZ(rotz)
 transform.Scale(1,1,1)

 transformFilter=vtk.vtkTransformFilter()
 transformFilter.SetTransform(transform)
 transformFilter.SetInputConnection(superq.GetOutputPort())
 transformFilter.Update()

 #get output as polydata
 superquadric = transformFilter.GetOutput()

 #get superquadric surfaces
 sSURFACES=superquadric.GetNumberOfCells()

 #recreate superquadric surface
 for surface in range(0,sSURFACES):
   
   #map particle data to superquadric surface
   j = 0
   for i in range(0,iARRAYS):
     iarray=iPOINTS.GetAbstractArray(i)
     #ignore rotation matrix
     if (i!=skipMindex):
       oarray=newCellData.GetAbstractArray(j)
       oarray.InsertTuple(oCELLSURFACES, body, iarray)
       j+=1
   oCELLSURFACES+=1 

   #get superquadric surface cell
   cell = superquadric.GetCell(surface)

   #get number of points per superquadric cell
   sCOUNT=cell.GetNumberOfPoints()

   #tranform points in original cell - rotation in x,y,z
   for j in range(0,sCOUNT): 
     pointid = cell.GetPointId(j)
     coord = superquadric.GetPoint(pointid)
     x, y, z = coord[:3]

     xnew=T11*x+T12*y+T13*z+r[0]
     ynew=T21*x+T22*y+T23*z+r[1]
     znew=T31*x+T32*y+T33*z+r[2]

     #add new cell point for output
     newPoints.InsertPoint(oCELLPOINTS, xnew, ynew, znew)

     oCELLPOINTS+=1

   #create new cell with transformed points
   newCells.InsertNextCell(sCOUNT)
   for j in range(0,sCOUNT):
     #add new cell point for output
     newCells.InsertCellPoint(oCELLPOINTS-j-1)

#set vtk type enum
VTK_EMPTY_CELL = 0
VTK_VERTEX = 1
VTK_POLY_VERTEX = 2
VTK_LINE = 3
VTK_POLY_LINE = 4
VTK_TRIANGLE = 5
VTK_TRIANGLE_STRIP = 6
#set new points and cells to ouput data
output.SetPoints(newPoints)
output.SetCells(VTK_TRIANGLE_STRIP,newCells)
#add new arrays to ouput data
for i in range(0,oARRAYS):
  oarray=newCellData.GetAbstractArray(i)
  output.GetCellData().AddArray(oarray)
