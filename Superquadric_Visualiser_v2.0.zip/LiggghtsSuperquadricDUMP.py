﻿#Programmable filter
#input = rigid*.dump
#output = vtkUnstructuredGrid

#change according to your dataset
quat1name = "quat1"
quat2name = "quat2"
quat3name = "quat3"
quat4name = "quat4"
n1name = "blockiness1"
n2name = "blockiness2"
scalename = "shape"
switchname = "is_wall"
mainaxis = 1 # main paraview axis (0=x,1=y,2=z), in newer Paraview versions usually y for superquadric particles
phiresolution = 6 # number of points in phi direction
thetaresolution = 6 # number of points in theta direction
toroid = 0 # is superquadric particle toroid (0=no, 1=yes)
toroidthickness = 1 # thickness of toroid (0=large hole, 1=small hole)
toroidmode = 0 # toroid visualisation mode (0=keep height, 1=keep surface) 
basicscale = 1 # basic superquadric scaling
precision = 1 # output precision (0=single, 1=double)

#imported libraries
import vtk

#input/output
input = self.GetInputDataObject(0,0)
output = self.GetOutputDataObject(0)

#input properties
iPOINTS=input.GetPointData()
iBODIES=input.GetNumberOfPoints()
iARRAYS=iPOINTS.GetNumberOfArrays()

#set main axis rotation
if mainaxis==0: # if Paraview superquadric main axis is x
  rotx = 0
  roty = 90
  rotz = 0
if mainaxis==1: # if Paraview superquadric main axis is y
  rotx = 90
  roty = 0
  rotz = 0
if mainaxis==2: # if Paraview superquadric main axis is z
  rotx = 0
  roty = 0
  rotz = 0

#prepare output
newPoints = vtk.vtkPoints()
newCells = vtk.vtkCellArray()
newCellData = vtk.vtkCellData()

#prepare output arrays
oARRAYS = 0
skipQ1index = -1
skipQ2index = -1
skipQ3index = -1
skipQ4index = -1
for i in range(0,iARRAYS):
 iarray=iPOINTS.GetAbstractArray(i)
 iname=iarray.GetName()
 icomp=iarray.GetNumberOfComponents()
 itype=iarray.GetDataType()
 #ignore quat - for faster skipping remember indexes
 if (iname!=quat1name) and (iname!=quat2name) and (iname!=quat3name) and (iname!=quat4name):
   oarray=vtk.vtkAbstractArray.CreateArray(itype)
   oarray.SetName(iname)   
   oarray.SetNumberOfComponents(icomp)
   newCellData.AddArray(oarray)    
   oARRAYS += 1     
 elif (iname==quat1name):
   skipQ1index = i
 elif (iname==quat2name):
   skipQ2index = i   
 elif (iname==quat3name):
   skipQ3index = i   
 elif (iname==quat4name):
   skipQ4index = i

#check consistency
j = 0
for i in range(0,iARRAYS):
 iarray=iPOINTS.GetAbstractArray(i)
 iname=iarray.GetName()
 #ignore quat
 if (i!=skipQ1index) and (i!=skipQ2index) and (i!=skipQ3index) and (i!=skipQ4index):
   oarray=newCellData.GetAbstractArray(j)
   oname=oarray.GetName()
   if (iname!=oname):
     print("Error: Non matching input/output array order!")
   j+=1

#create superquadric glyphs
oCELLPOINTS=0  
oCELLSURFACES=0 
for body in range(0,iBODIES):

 #skip data if switch is applied
 bswitcharr = iPOINTS.GetArray(switchname)
 if bswitcharr is not None:
   bswitch = bswitcharr.GetValue(body)
   if bswitch==1:
     continue
 
 #get parameters for superquadric particle

 #get particle position
 r=input.GetPoint(body)

 #get particle quaternions for rotation
 Q1=iPOINTS.GetArray(quat1name).GetValue(body)
 Q2=iPOINTS.GetArray(quat2name).GetValue(body)
 Q3=iPOINTS.GetArray(quat3name).GetValue(body)
 Q4=iPOINTS.GetArray(quat4name).GetValue(body)

 #get particle blockiness and shape factors
 n1 = iPOINTS.GetArray(n1name).GetValue(body)
 n2 = iPOINTS.GetArray(n2name).GetValue(body)
 scalex = iPOINTS.GetAbstractArray(scalename).GetComponent(body,0)
 scaley = iPOINTS.GetAbstractArray(scalename).GetComponent(body,1)
 scalez = iPOINTS.GetAbstractArray(scalename).GetComponent(body,2)

 #set toroid representation - make particle with correct height or surface
 if toroid==1:
   if toroidmode==0:
     if toroidthickness!=0:
       scalez = (1.0/toroidthickness+1.0)*scalez
     else:
       scalez = 1.0*scalez
   else:
     scalez = 1.0*scalez

 #compute rotation matrix
 T11=Q2*Q2+Q1*Q1-Q3*Q3-Q4*Q4
 T12=2*(Q2*Q3-Q1*Q4)
 T13=2*(Q2*Q4+Q1*Q3)
 T21=2*(Q1*Q4+Q2*Q3)
 T22=Q1*Q1-Q2*Q2+Q3*Q3-Q4*Q4
 T23=2*(Q3*Q4-Q1*Q2)
 T31=2*(Q2*Q4-Q1*Q3)
 T32=2*(Q1*Q2+Q3*Q4)
 T33=Q1*Q1-Q2*Q2-Q3*Q3+Q4*Q4

 #make superquadric source
 superq = vtk.vtkSuperquadricSource()
 superq.SetCenter(0, 0, 0)
 superq.SetScale(scalex, scaley, scalez)
 superq.SetPhiRoundness(2.0/n1)
 superq.SetThetaRoundness(2.0/n2)
 superq.SetThickness(toroidthickness)
 superq.SetToroidal(toroid)
 superq.SetSize(basicscale)
 superq.SetPhiResolution(phiresolution)
 superq.SetThetaResolution(thetaresolution)
 superq.SetOutputPointsPrecision(precision)

 #rotate to basic z orientation
 transform = vtk.vtkTransform()
 transform.Translate(0,0,0)
 transform.RotateX(rotx)
 transform.RotateY(roty)
 transform.RotateZ(rotz)
 transform.Scale(1,1,1)

 transformFilter=vtk.vtkTransformFilter()
 transformFilter.SetTransform(transform)
 transformFilter.SetInputConnection(superq.GetOutputPort())
 transformFilter.Update()

 #get output as polydata
 superquadric = transformFilter.GetOutput()

 #get superquadric surfaces
 sSURFACES=superquadric.GetNumberOfCells()

 #recreate superquadric surface
 for surface in range(0,sSURFACES):
   
   #map particle data to superquadric surface
   j = 0
   for i in range(0,iARRAYS):
     iarray=iPOINTS.GetAbstractArray(i)
     #ignore quat
     if (i!=skipQ1index) and (i!=skipQ2index) and (i!=skipQ3index) and (i!=skipQ4index):
       oarray=newCellData.GetAbstractArray(j)
       oarray.InsertTuple(oCELLSURFACES, body, iarray)
       j+=1
   oCELLSURFACES+=1 

   #get superquadric surface cell
   cell = superquadric.GetCell(surface)

   #get number of points per superquadric cell
   sCOUNT=cell.GetNumberOfPoints()

   #tranform points in original cell - rotation in x,y,z
   for j in range(0,sCOUNT): 
     pointid = cell.GetPointId(j)
     coord = superquadric.GetPoint(pointid)
     x, y, z = coord[:3]

     xnew=T11*x+T12*y+T13*z+r[0]
     ynew=T21*x+T22*y+T23*z+r[1]
     znew=T31*x+T32*y+T33*z+r[2]

     #add new cell point for output
     newPoints.InsertPoint(oCELLPOINTS, xnew, ynew, znew)

     oCELLPOINTS+=1

   #create new cell with transformed points
   newCells.InsertNextCell(sCOUNT)
   for j in range(0,sCOUNT):
     #add new cell point for output
     newCells.InsertCellPoint(oCELLPOINTS-j-1)

#set vtk type enum
VTK_EMPTY_CELL = 0
VTK_VERTEX = 1
VTK_POLY_VERTEX = 2
VTK_LINE = 3
VTK_POLY_LINE = 4
VTK_TRIANGLE = 5
VTK_TRIANGLE_STRIP = 6
#set new points and cells to ouput data
output.SetPoints(newPoints)
output.SetCells(VTK_TRIANGLE_STRIP,newCells)
#add new arrays to ouput data
for i in range(0,oARRAYS):
  oarray=newCellData.GetAbstractArray(i)
  output.GetCellData().AddArray(oarray)
